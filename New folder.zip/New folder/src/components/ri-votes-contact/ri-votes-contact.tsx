import { Component, Prop, h, Element, State } from '@stencil/core';

@Component({
  tag: 'ri-votes-contact',
  styleUrl: 'ri-votes-contact.css',
  shadow: false,
})
export class RIVotesHeader {
  @Element() el: HTMLElement;
  @Prop() first: string;
  @State() isMenuOpen: boolean = false;
  @State() showMenu: boolean = false;
  //   @Event() todo

  render() {
    return (
      <div class="ri-votes-contact row">
        <div class="col-lg-6">
          <div class="contact-info-container margin-left-fix">
            <h3 class="ri-votes-contact-header ">Contact Info:</h3>
            <div class="contact-info-row d-flex">
              <span>
                <i class="fa fa-location-arrow fa-2x"></i>
              </span>{' '}
              <p>148 West River Street, Providence, RI 02904</p>
            </div>
            <div class="contact-info-row d-flex ">
              <span id="contact-row-number">
                <i class="fa fa-mobile fa-2x"></i>
              </span>{' '}
              <p>Call Us: 401-222-2340</p>
            </div>
          </div>
          <div class="stay-connected-container margin-left-fix">
            <h3 class="ri-votes-contact-header mt-sm-5">Stay Connected:</h3>
            <div class="">
              <span></span>
              <span></span>
              <span></span>
              <div class="social-container">
                <ul>
                  <li class="social-item">
                    <a href="https://twitter.com/risecstate" target="_blank" class="social__link bg-color">
                      <i class="social__icon fa fa-twitter"></i>
                      {/* <span style="display:none;">Twitter</span> */}
                    </a>
                  </li>
                  <li class="social-item">
                    <a href="https://www.facebook.com/RIDepartmentOfState/" target="_blank" class="social__link bg-color">
                      <i class="social__icon fa fa-facebook"></i>
                      {/* <span style="display:none;">facebook</span> */}
                    </a>
                  </li>
                  <li class="social-item">
                    <a href="https://www.instagram.com/myrihistory/" target="_blank" class="social__link bg-color">
                      <i class="social__icon fa fa-instagram"></i>
                      {/* <span style="display:none;">Instagram</span> */}
                    </a>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        <div class="col-lg-6">
          <div class="contact-info-container right-side">
            <h3 class="ri-votes-contact-header mt-sm-5 mt-md-0">eNews Signup:</h3>
            <div class="news-signup-container">
              <p>To join our mailing list, please complete the information below and click Sign Up.</p>
              <form id="enews-signup-form">
                <div class="contact-input-control">
                  <label>Email Address</label>
                  <label id="email-error" class="error-msg"></label>
                  <input type="text" />
                </div>
                <div class="contact-input-control">
                  <label>First Name</label>
                  <label id="first-name-error" class="error-msg"></label>
                  <input type="text" />
                </div>
                <div class="contact-input-control">
                  <label>Last Name</label>
                  <label id="last-name-error" class="error-msg"></label>
                  <input type="text" />
                </div>
                <button id="enews-submit" type="submit">
                  Sign Up
                </button>
              </form>
              <p class="ctct-form-footer">
                By submitting this form, you are granting: Secretary of State Nellie M. Gorbea, State House, Providence, Rhode Island, 02903-1120, United States, https://sos.ri.gov
                permission to email you. You may unsubscribe via the link found at the bottom of every email. (See our{' '}
                <a href="https://www.constantcontact.com/legal/privacy-statement" target="_blank">
                  Email Privacy Policy
                </a>{' '}
                for details.) Emails are serviced by Constant Contact.
              </p>
            </div>
          </div>
        </div>
      </div>
    );
  }
}
