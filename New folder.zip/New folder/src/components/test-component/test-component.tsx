import { Component, h, Element, State } from '@stencil/core';
import 'bootstrap/dist/css/bootstrap.css';
import 'bootstrap/dist/js/bootstrap.js';
// import 'react-bootstrap/dist/react-bootstrap.min.js';
// import { Container, Row, Col } from 'react-bootstrap';

@Component({
  tag: 'test-component',
  styleUrl: 'test-component.css',
  shadow: true,
})
export class TestComponent {
  @State() showMenu = false;

  toggleMenu() {
    this.showMenu = !this.showMenu;
  }

  render() {
    return (
      <div>
        <button onClick={() => this.toggleMenu()}>Toggle Menu</button>
        <div class={`menu ${this.showMenu ? 'show' : 'hide'}`}>
          <ul>
            <li>
              <a href="#">Menu Item 1</a>
            </li>
            <li>
              <a href="#">Menu Item 2</a>
            </li>
            <li>
              <a href="#">Menu Item 3</a>
            </li>
          </ul>
        </div>
      </div>
    );
  }
}
