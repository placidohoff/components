import { Component, Prop, h, Element, State } from '@stencil/core';

@Component({
  tag: 'ri-votes-header',
  styleUrl: 'ri-votes-header.css',
  shadow: true,
})
export class RIVotesHeader {
  @Element() el: HTMLElement;
  @Prop() first: string;
  @State() isMenuOpen: boolean = false;
  @State() showMenu: boolean = false;
  @State() showMobileSubMenu = false;
  @State() testToggle = false;
  //   @Event() todo

  onTest() {
    // alert('hello');
    // console.log('testing...');

    // var x = document.getElementById('myLinks');
    // if (x.style.display === 'block') {
    //   x.style.display = 'none';
    // } else {
    //   x.style.display = 'block';
    // }
    // const x = this.el.shadowRoot.querySelector('#myLinks');
    alert('test');
    // document.getElementById('myLinks').style.display = 'block';
    const x = document.querySelector('#myLinks');
    console.log(x);
    x.setAttribute('disabled', 'block');
  }

  menuToggle() {
    this.showMenu = !this.showMenu;
    // alert('test');
  }

  testToggleController() {
    this.testToggle = !this.testToggle;
  }

  toggleMobileSubMenu = () => {
    this.showMobileSubMenu = !this.showMobileSubMenu;
  };

  myFunction = () => {};
  render() {
    return (
      <div class="header">
        <div class="header-container container d-none d-sm-none d-md-flex">
          <div class="logo-display-container">
            <a href="/">
              <img class="img-responsive coatofarms" src="images/coa.png" alt="Rhode Island State Seal" />
            </a>
            <div
              tabindex="0"
              aria-label="Rhode Island Secretary of State, Gregg Amore"
              class="logo-text-display"
              //   style="margin-left: 5px"
            >
              <p class="ri-dept-state">Rhode Island Department of State</p>
              <p class="amore hide-for-small">Gregg M. Amore</p>
              <p class="hide-for-small">Secretary of State</p>
            </div>
          </div>
          <nav tabindex="0" aria-label="site navigation" class={'hide-for-small'}>
            <ul class="nav-items">
              <li tabindex="0" class="dropbtn">
                Why Voting Matters
              </li>

              <li tabindex="0">
                <ul class="dropdown dropbtn">
                  Voter Registration
                  <div class="dropdown-content">
                    <a href="#">Check Registration</a>
                    <a href="#">Register to Vote</a>
                  </div>
                </ul>
              </li>
              <li tabindex="0">
                <ul class="dropdown dropbtn">
                  Ways to Vote
                  <div class="dropdown-content">
                    <a href="#">At The Polls</a>
                    <a href="#">By Mail</a>
                    <a href="#">Emergency Ballot</a>
                  </div>
                </ul>
              </li>
            </ul>
          </nav>
          {/* <a href="javascript:void(0);" class="icon show-for-small-only" onClick={() => myFunction}>
            <i class="fa fa-bars"></i>
          </a> */}
          {/* <input type="checkbox" id="menu-toggle" /> */}
          <div class={'hamburger-container show-for-small-only'}>
            <div class="hamburger-icon parent" onClick={() => this.menuToggle()}>
              {this.showMenu ? (
                <span>x</span>
              ) : (
                <div class="hamburger-stripes">
                  <div class="top"></div>
                  <div class="meat"></div>
                  <div class="bottom"></div>
                </div>
              )}
            </div>
          </div>
        </div>
        {/* <input type="checkbox" id="toggle1" /> */}

        <div id="myLinks" class={this.showMenu ? 'show-mobile-nav' : 'hide-mobile-nav'}>
          <a href="#news">Why Voting Matters</a>

          <a class="dropdown dropdown-mobile-navitem" onClick={() => this.toggleMobileSubMenu()}>
            <div class="dropdown-mobile-label">
              Voter Registration
              <i class="fa fa-caret-down"></i>
            </div>

            <div class={`mx-5 dropdown-content drop-content-mobile`}>
              <a class={`transition ${this.showMobileSubMenu ? 'reveal-link' : 'hide-link'}`} href="#">
                Check Registration
              </a>
              <a class={`transition ${this.showMobileSubMenu ? 'reveal-link' : 'hide-link'}`} href="#">
                Get Registered
              </a>
            </div>
          </a>

          <a class="dropdown dropdown-mobile-navitem" onClick={() => this.toggleMobileSubMenu()}>
            <div class="dropdown-mobile-label">
              Ways to Vote
              <i class="fa fa-caret-down"></i>
            </div>

            <div class={`mx-5 dropdown-content drop-content-mobile`}>
              <a class={`transition ${this.showMobileSubMenu ? 'reveal-link' : 'hide-link'}`} href="#">
                At The Polls
              </a>
              <a class={`transition ${this.showMobileSubMenu ? 'reveal-link' : 'hide-link'}`} href="#">
                By Mail
              </a>
              <a class={`transition ${this.showMobileSubMenu ? 'reveal-link' : 'hide-link'}`} href="#">
                Emergency Ballot
              </a>
            </div>
          </a>
        </div>
      </div>
    );
  }
}
