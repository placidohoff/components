import { Component, Prop, h, Element, State } from '@stencil/core';

@Component({
  tag: 'ri-votes-header',
  styleUrl: 'ri-votes-header.css',
  shadow: true,
})
export class RIVotesHeader {
  @Element() el: HTMLElement;
  @Prop() first: string;
  @State() isMenuOpen: boolean = false;
  //   @Event() todo

  onTest() {
    // alert('hello');
    // console.log('testing...');

    // var x = document.getElementById('myLinks');
    // if (x.style.display === 'block') {
    //   x.style.display = 'none';
    // } else {
    //   x.style.display = 'block';
    // }
    const x = this.el.shadowRoot.querySelector('#myLinks');
  }

  menuToggle() {
    this.isMenuOpen = !this.isMenuOpen;
  }

  myFunction = () => {};
  render() {
    return (
      <div class="header">
        <div class="header-container container d-none d-sm-none d-md-flex">
          <div class="logo-display-container">
            <img class="img-responsive coatofarms" src="images/coa.png" alt="Rhode Island State Seal" />
            <div
              tabindex="0"
              aria-label="Rhode Island Secretary of State, Gregg Amore"
              class="logo-text-display"
              //   style="margin-left: 5px"
            >
              <p class="ri-dept-state">Rhode Island Department of State</p>
              <p class="amore hide-for-small">Gregg M. Amore</p>
              <p class="hide-for-small">Secretary of State</p>
            </div>
          </div>
          <nav tabindex="0" aria-label="site navigation" class={'hide-for-small'}>
            <ul class="nav-items">
              <li tabindex="0">Menu item</li>
              <li tabindex="0">Menu item</li>
              <li tabindex="0">Menu item</li>
            </ul>
          </nav>
          {/* <a href="javascript:void(0);" class="icon show-for-small-only" onClick={() => myFunction}>
            <i class="fa fa-bars"></i>
          </a> */}
          <div class={'hamburger-container show-for-small-only'}>
            <div class="hamburger-icon" onClick={this.onTest}>
              {/* <i class="fa fa-bars"></i> */}X
            </div>
          </div>
        </div>

        <div id="myLinks">
          <a href="#news">News</a>
          <a href="#contact">Contact</a>
          <a href="#about">About</a>
        </div>
      </div>
    );
  }
}
