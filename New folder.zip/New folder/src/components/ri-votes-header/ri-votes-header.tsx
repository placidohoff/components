import { Component, Prop, h } from '@stencil/core';

@Component({
  tag: 'ri-votes-header',
  styleUrl: 'ri-votes-header.css',
  shadow: true,
})
export class RIVotesHeader {
  //   private getText(): string {
  //     return format(this.first, this.middle, this.last);
  //   }
  @Prop() first: string;
  render() {
    return (
      <div class="header">
        <div class="header-container container d-none d-sm-none d-md-flex">
          <div class="logo-display-container">
            <img class="img-responsive coatofarms" src="images/coa.png" alt="Rhode Island State Seal" />
            <div
              tabindex="0"
              aria-label="Rhode Island Secretary of State, Gregg Amore"
              class="logo-text-display"
              //   style="margin-left: 5px"
            >
              <p>Rhode Island Department of State</p>
              <p class="amore hide-for-small">Gregg M. Amore</p>
              <p class="hide-for-small">Secretary of State</p>
            </div>
          </div>
          <nav tabindex="0" aria-label="site navigation" class={'hide-for-small'}>
            <ul class="nav-items">
              <li tabindex="0">Menu item</li>
              <li tabindex="0">Menu item</li>
              <li tabindex="0">Menu item</li>
            </ul>
          </nav>
        </div>
      </div>
    );
  }
}
