import { Component, h, Element, State } from '@stencil/core';
import 'bootstrap/dist/css/bootstrap.css';
import 'bootstrap/dist/js/bootstrap.js';
// import 'react-bootstrap/dist/react-bootstrap.min.js';
// import { Container, Row, Col } from 'react-bootstrap';

@Component({
  tag: 'ri-votes-key-dates',
  styleUrl: 'ri-votes-key-dates.css',
  shadow: false,
})
export class RIVotesHeader {
  @Element() el: HTMLElement;
  @State() isMenuOpen: boolean = false;
  @State() showMenu: boolean = false;
  //   @Event() todo

  myFunction = () => {};
  render() {
    return (
      <div id="ri-votes-key-dates" class="row mt-5 mb-5">
        <div class="col-md-6 mt-5 d-flex justify-content-lg-end">
          <div class="ml-5">
            <div class="d-flex align-items-center mb-5">
              {/* <img class="img-fluid" src="images/key-dates-icon.png" alt="key dates icon" /> */}
              <div class={'key-votes-header'}>
                <span>
                  <i class="fa fa-circle-o" aria-hidden="true"></i>
                </span>
              </div>
              <h4>Key Dates</h4>
            </div>
            <ul class="check-list">
              <li>
                <strong>August 14</strong>&nbsp;-&nbsp;Deadline to register to vote in the primaries
              </li>
              <li>
                <strong>August 23</strong>&nbsp;-&nbsp;Last day to submit a mail ballot application for the primary
              </li>
              <li>
                <strong>August 23</strong>&nbsp;-&nbsp;Last day to apply for a Braille or tactile ballot for the primaries
              </li>
              <li>
                <strong>August 24</strong> - First day of Early Voting
              </li>
              <li>
                <strong>September 12</strong>&nbsp;-&nbsp;Last day of Early Voting
              </li>
              <li>
                <strong>September 13</strong>&nbsp;-&nbsp;Party Primaries
              </li>

              <li>
                <strong>October 9</strong>&nbsp;-&nbsp;Last day to register to vote for the General Election
              </li>
              <li>
                <strong>October 18</strong>&nbsp;-&nbsp;Last day to apply for a General Election mail ballot
              </li>
              <li>
                <strong>October 18</strong>&nbsp;-&nbsp;Last day to apply for a Braille or Tactile ballot for the General Election
              </li>
              <li>
                <strong>October 19</strong> - First day of Early Voting for the General Election
              </li>
              <li>
                <strong>November 7</strong>&nbsp;-&nbsp;Last day of Early Voting for the General Election
              </li>
              <li>
                <strong>November 8</strong>&nbsp;-&nbsp;General Election
              </li>
            </ul>
          </div>
        </div>
        <div class="col-md-6 mt-5 key-dates-right">
          <div class="ml-5">
            <div class="d-flex align-items-center mb-3">
              {/* <img class="img-fluid" src="images/key-dates-icon.png" alt="key dates icon" /> */}
              <div class={'key-votes-header'}>
                <span>
                  <i class="fa fa-circle-o" aria-hidden="true"></i>
                </span>
              </div>
              <h4>Get Involved</h4>
            </div>

            <a class="key-dates-link" title="#RIVotes #BeAVoter on Twitter" target="_blank" href='https://twitter.com/search?q=%23RIVotes+OR+(%23BeAVoter+AND+"RI")'>
              #RIVotes #BeAVoter
            </a>
            <br />
            <a class="key-dates-link-smaller" target="_blank" href='https://twitter.com/search?q=%23RIVotes+OR+(%23BeAVoter+AND+"RI")'>
              #RIVotes #BeAVoter Tweets
            </a>
          </div>
        </div>
      </div>
    );
  }
}
