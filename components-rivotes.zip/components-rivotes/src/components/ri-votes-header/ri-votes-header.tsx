import { Component, Prop, h, Element, State } from '@stencil/core';

@Component({
  tag: 'ri-votes-header',
  styleUrl: 'ri-votes-header.css',
  shadow: true,
})
export class RIVotesHeader {
  @Element() el: HTMLElement;
  @Prop() first: string;
  @State() isMenuOpen: boolean = false;
  @State() showMenu: boolean = false;
  @State() showMobileSubMenu: boolean = false;
  @State() showMobileSubMenuArray = [false, false, false];
  @State() showVoterRegistrationMenu = false;
  @State() showWaysToVoteMenu = false;
  @State() whyVotingMattersLink = 'why-voting-matters.html';
  @State() voteEmergencyBallotLink = 'vote-by-emergency-ballot.html';
  @State() voteByMailLink = 'vote-by-mail.html';
  @State() voteAtPollsLink = 'vote-at-polls.html';
  @State() checkRegistrationLink = 'check-voter-registration.html';
  @State() getRegisteredLink = 'get-registered-to-vote.html';

  menuToggle() {
    this.showMenu = !this.showMenu;
    // alert('test');
  }

  toggleMobileSubMenu = index => {
    // this.closeAllMobileSubNav();
    if (index == 1) {
      this.showVoterRegistrationMenu = !this.showVoterRegistrationMenu;
      this.showWaysToVoteMenu = false;
    }

    if (index == 2) {
      this.showWaysToVoteMenu = !this.showWaysToVoteMenu;
      this.showVoterRegistrationMenu = false;
    }

    console.log(index, this.showVoterRegistrationMenu, this.showWaysToVoteMenu);
  };

  closeAllMobileSubNav = () => {
    this.showVoterRegistrationMenu = false;
    this.showWaysToVoteMenu = false;
  };

  myFunction = () => {};
  render() {
    return (
      <div class="header">
        <div class="header-container container d-none d-sm-none d-md-flex">
          <div class="logo-display-container">
            <a href="/">
              <img class="img-responsive coatofarms" src="images/coa.png" alt="Rhode Island State Seal" />
            </a>
            <div
              tabindex="0"
              aria-label="Rhode Island Secretary of State, Gregg Amore"
              class="logo-text-display"
              //   style="margin-left: 5px"
            >
              <p class="ri-dept-state">Rhode Island Department of State</p>
              <p class="amore hide-for-small">Gregg M. Amore</p>
              <p class="hide-for-small">Secretary of State</p>
            </div>
          </div>
          <nav tabindex="0" aria-label="site navigation" class={'hide-for-small'}>
            <ul class="nav-items">
              <li tabindex="0" class="dropbtn" onClick={() => (window.location.href = this.whyVotingMattersLink)}>
                Why Voting Matters
              </li>

              <li tabindex="0">
                <ul class="dropdown dropbtn">
                  Voter Registration
                  <div class="dropdown-content">
                    <a href={this.checkRegistrationLink}>Check Registration</a>
                    <a href={this.getRegisteredLink}>Register to Vote</a>
                  </div>
                </ul>
              </li>
              <li tabindex="0">
                <ul class="dropdown dropbtn">
                  Ways to Vote
                  <div class="dropdown-content">
                    <a href={this.voteAtPollsLink}>At The Polls</a>
                    <a href={this.voteByMailLink}>By Mail</a>
                    <a href={this.voteEmergencyBallotLink}>Emergency Ballot</a>
                  </div>
                </ul>
              </li>
            </ul>
          </nav>
          {/* <a href="javascript:void(0);" class="icon show-for-small-only" onClick={() => myFunction}>
            <i class="fa fa-bars"></i>
          </a> */}
          {/* <input type="checkbox" id="menu-toggle" /> */}
          <div class={'hamburger-container show-for-small-only'}>
            <div class="hamburger-icon parent" onClick={() => this.menuToggle()}>
              {this.showMenu ? (
                <span>x</span>
              ) : (
                <div class="hamburger-stripes">
                  <div class="top"></div>
                  <div class="meat"></div>
                  <div class="bottom"></div>
                </div>
              )}
            </div>
          </div>
        </div>
        {/* <input type="checkbox" id="toggle1" /> */}

        <div id="myLinks" class={this.showMenu ? 'show-mobile-nav' : 'hide-mobile-nav'}>
          <a class="dropdown-mobile-label" href={this.whyVotingMattersLink}>
            Why Voting Matters
          </a>

          <a class="dropdown dropdown-mobile-navitem" onClick={() => this.toggleMobileSubMenu(1)}>
            <div class="dropdown-mobile-label">
              Voter Registration
              <i class="fa fa-caret-down"></i>
            </div>

            <div class={`mx-5 dropdown-content drop-content-mobile`}>
              <a class={`transition ${this.showVoterRegistrationMenu == true ? 'reveal-link' : 'hide-link'}`} href={this.checkRegistrationLink}>
                Check Registration
              </a>
              <a class={`transition ${this.showVoterRegistrationMenu ? 'reveal-link' : 'hide-link'}`} href={this.getRegisteredLink}>
                Get Registered
              </a>
            </div>
          </a>

          <a class="dropdown dropdown-mobile-navitem" onClick={() => this.toggleMobileSubMenu(2)}>
            <div class="dropdown-mobile-label">
              Ways to Vote
              <i class="fa fa-caret-down"></i>
            </div>

            <div class={`mx-5 dropdown-content drop-content-mobile`}>
              <a class={`transition ${this.showWaysToVoteMenu ? 'reveal-link' : 'hide-link'}`} onClick={e => e.stopPropagation()} href={this.voteAtPollsLink}>
                At The Polls
              </a>
              <a class={`transition ${this.showWaysToVoteMenu ? 'reveal-link' : 'hide-link'}`} onClick={e => e.stopPropagation()} href={this.voteByMailLink}>
                By Mail
              </a>
              <a class={`transition ${this.showWaysToVoteMenu ? 'reveal-link' : 'hide-link'}`} onClick={e => e.stopPropagation()} href={this.voteEmergencyBallotLink}>
                Emergency Ballot
              </a>
            </div>
          </a>
        </div>
      </div>
    );
  }
}
